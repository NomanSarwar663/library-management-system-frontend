const Page404 = () => {

    return (
        "This is the Page404 page"
    );
}

export default Page404;